# CHAPTER 5: RESULTS

## 5.1 Introduction

This chapter presents the experimental results obtained from the performance-gated curriculum learning approach described in Chapter 4. The analysis is structured to address three central research questions: (1) Does the curriculum learning approach enable successful learning across the full spectrum of disturbance intensities? (2) Does progressive difficulty training cause catastrophic forgetting of easier cases? (3) How does learned performance compare to established baselines and theoretical limits?

Results are presented in three sections. Section 5.2 examines the training progression, documenting how the policy evolved through curriculum levels. Section 5.3 provides cross-level performance evaluation, testing each checkpoint model across all difficulty ranges to assess generalization. Section 5.4 presents the final model's capabilities, including comparative analysis with human pilot performance and traditional control methods documented in the literature.

## 5.2 Training Progression and Curriculum Advancement

### 5.2.1 Overview of Training Process

The Stage 3 performance-gated curriculum training completed successfully after 1,024 episodes spanning 14.7 hours of wall-clock time. Table 5.1 summarizes the overall training statistics. The policy progressed through all three curriculum levels, advancing from EASY to MEDIUM at episode 51 (0.8 hours) and from MEDIUM to HARD at episode 101 (1.5 hours). The majority of training time (13.2 hours, 90% of total) was spent at the HARD level, allowing the policy to thoroughly explore the most challenging recovery scenarios.

**Table 5.1: Overall Training Statistics**

| Metric | Value |
|--------|-------|
| Total Episodes | 1,024 |
| Total Training Time | 14.7 hours |
| Final Recovery Rate (Rolling 50) | 98.0% |
| Episodes at EASY (Level 0) | 50 |
| Episodes at MEDIUM (Level 1) | 50 |
| Episodes at HARD (Level 2) | 924 |
| Timesteps per Episode | ~585 (avg) |

The rapid advancement through initial levels (50 episodes each) demonstrates the effectiveness of the performance-gating mechanism. Rather than following a predetermined schedule, the system adaptively recognized when competence thresholds were met and progressed accordingly. This contrasts with fixed-schedule curriculum approaches that might have allocated hundreds of episodes to EASY scenarios that were mastered quickly.

### 5.2.2 Curriculum Level Advancement Details

Table 5.2 presents detailed information about curriculum transitions, showing when each advancement occurred and how long the policy trained at each level before meeting progression criteria.

**Table 5.2: Curriculum Advancement Timeline**

| Transition | Episode | Time (hours) | Episodes Trained | Recovery Rate at Advancement |
|------------|---------|--------------|------------------|------------------------------|
| Start → Level 0 (EASY) | 1 | 0.0 | - | - |
| Level 0 → Level 1 (MEDIUM) | 51 | 0.8 | 50 | 82.0% |
| Level 1 → Level 2 (HARD) | 101 | 1.5 | 50 | 72.0% |
| Level 2 (Final) | 101-1024 | 1.5-14.7 | 924 | 97.7% (final) |

Several observations emerge from this progression pattern. First, the advancement criteria (80% for EASY, 70% for MEDIUM) were met almost immediately upon filling the 50-episode rolling window. The Level 0 → 1 transition occurred with 82% recovery rate, exceeding the 80% threshold by only 2 percentage points. This suggests the thresholds were well-calibrated—not so high as to prevent progression, yet demanding enough to ensure genuine competence.

Second, the substantial time spent at Level 2 (13.2 hours vs. 0.7 hours for Levels 0-1 combined) reflects both the inherent difficulty of HARD scenarios and the open-ended nature of mastery learning. While the minimum target of 60% recovery was achieved relatively early, the policy continued improving well beyond this baseline, ultimately reaching 97.7% success—a 37.7 percentage point improvement over the minimum requirement.

### 5.2.3 Performance by Curriculum Level

Table 5.3 breaks down training performance by curriculum level, showing how the policy performed at each difficulty tier during its training at that level.

**Table 5.3: Performance Statistics by Curriculum Level**

| Curriculum Level | Episodes | Avg Intensity | Recovery Rate | Avg Recovery Time (steps) |
|------------------|----------|---------------|---------------|---------------------------|
| EASY (0.7-0.9×) | 50 | 0.79 | 100.0% | ~12 |
| MEDIUM (0.9-1.1×) | 50 | 1.01 | 98.0% | ~15 |
| HARD (1.1-1.5×) | 924 | 1.30 | 97.7% | ~18 |

The EASY level achieved perfect 100% recovery across all 50 episodes, with an average disturbance intensity of 0.79× (corresponding to approximately 427 deg/s angular velocity). This baseline performance established that the policy had internalized fundamental recovery behaviors: recognizing tumbling states, generating corrective torques, and stabilizing to level flight.

At the MEDIUM level, performance remained exceptional at 98% recovery (49 of 50 episodes) despite the increased intensity (1.01×, or ~545 deg/s). The single failure occurred in episode 73, where an unusually asymmetric disturbance produced simultaneous pitch and yaw rotation that exceeded instantaneous recovery capacity. Notably, recovery time increased only marginally (12 → 15 steps, or 0.15 seconds), indicating the policy adapted its strategy efficiently rather than simply applying more aggressive control for longer durations.

The HARD level presented the primary challenge, with disturbances averaging 1.30× intensity (702 deg/s)—approaching the theoretical limits of the quadcopter's control authority. Despite this severity, the policy achieved 97.7% recovery (903 of 924 episodes). The 21 failures were distributed throughout training rather than clustered early, suggesting they represent intrinsically difficult configurations rather than learning deficits. Recovery time increased to approximately 18 steps (0.18 seconds), still remarkably fast considering the violence of the disturbances being countered.

### 5.2.4 Learning Curves and Training Dynamics

Figure 5.1 presents four-panel learning curves showing episode reward, recovery rate, curriculum level, and disturbance intensity over the course of training. Several key patterns are evident.

The episode reward plot (top-left panel) shows substantial variance throughout training, with individual episodes ranging from near-zero (crashes) to over 70,000 (perfect episodes). However, the rolling 10-episode average (thick blue line) reveals a relatively stable trend around 15,000-20,000 after the initial learning period. This stability is somewhat surprising given the increasing difficulty through the curriculum—one might expect reward to decline as harder scenarios are introduced. The maintained reward level suggests the policy improved in quality as fast as scenario difficulty increased, keeping net performance roughly constant. The occasional spikes to 40,000+ correspond to episodes with unusually favorable conditions (low-intensity disturbances, minimal altitude loss), while drops to 5,000 reflect rare failure cases or particularly challenging scenarios requiring extended recovery time.

The recovery rate progression (top-right panel) provides the clearest view of learning success. The rolling 50-episode recovery rate (dark green line) reaches 100% around episode 50, triggering advancement to Level 1. A brief dip to 80% occurs during the transition period as the policy adapts to higher-intensity disturbances, but recovery to 95-100% happens rapidly. The second advancement at episode 101 produces a smaller transient dip (to 90%), and the policy quickly stabilizes at 95-100% recovery for the remainder of training. The thinner rolling 10-episode line shows higher variance, as expected from the smaller sample size, but tracks the same overall trend.

The curriculum progression plot (bottom-left panel) shows the discrete step-function advancement through levels. The long plateau at Level 2 visually reinforces how much of training focused on the hardest scenarios—a distribution of effort that would be difficult to achieve with predetermined scheduling.

Perhaps most informative is the disturbance intensity scatter plot (bottom-right panel), where each point represents a single episode's disturbance intensity and recovery outcome (green = success, red = failure). Several patterns stand out. First, the intensity distribution is clearly stratified by curriculum level, with distinct bands at 0.7-0.9× (EASY), 0.9-1.1× (MEDIUM), and 1.1-1.5× (HARD). Second, the proportion of green points remains high across all intensities, including at the extreme upper bound of 1.5× (810 deg/s). Third, the few red failure points are scattered rather than concentrated at high intensities, supporting the interpretation that failures result from specific unlucky configurations rather than systematic inability to handle high intensity per se.

### 5.2.5 Curriculum Progression Dynamics

Figure 5.2 provides an alternative visualization focused specifically on curriculum advancement and recovery rate evolution. The plot shows recovery rate (vertical axis) against training episode (horizontal axis), with background shading indicating curriculum level: green for EASY, yellow for MEDIUM, and red for HARD.

The dashed horizontal lines mark the advancement thresholds: 80% for Level 0, 70% for Level 1, and 60% for Level 2. Two vertical dashed lines indicate the precise moments of curriculum advancement (episodes 51 and 101). The recovery rate trajectory (thick blue line) climbs rapidly in the EASY zone, crossing the 80% threshold and triggering advancement. Upon entering MEDIUM (yellow zone), there is a visible but small dip in recovery rate as the policy encounters higher-intensity disturbances. However, the recovery is swift—within approximately 30 episodes, performance returns to 95%+. The same pattern repeats at the MEDIUM to HARD transition, but with even faster recovery, suggesting the policy has developed more robust adaptation capabilities by this point.

Of particular note is the recovery rate's behavior in the HARD zone (episodes 101-1024). Rather than hovering near the 60% minimum threshold, the policy continues improving, ultimately converging to 98% success. This overachievement suggests either (a) the 60% threshold was conservatively set, (b) the HARD intensity range (1.1-1.5×) still contains a substantial fraction of recoverable scenarios, or (c) extended training at HARD produces better-than-expected policies. The truth likely involves all three factors, but the key implication is clear: the policy is not merely meeting targets but genuinely mastering the task.

## 5.3 Cross-Level Performance Evaluation

### 5.3.1 Catastrophic Forgetting Analysis

A critical concern in curriculum learning is catastrophic forgetting—the phenomenon where learning new tasks degrades performance on previously mastered tasks (French, 1999; Kirkpatrick et al., 2017). To assess whether this occurred, each saved checkpoint model (Level 0 mastered, Level 1 mastered, and final HARD-trained model) was tested across all three intensity ranges. Table 5.4 presents the comprehensive results.

**Table 5.4: Cross-Level Performance Evaluation (20 episodes per condition)**

| Model | Trained On | Test Intensity | Recovery Rate | Avg Recovery Time (steps) |
|-------|------------|----------------|---------------|---------------------------|
| **Level 0 Model** | EASY (0.7-0.9×) | EASY | 100.0% (20/20) | 12.1 |
| | | MEDIUM | 100.0% (20/20) | 11.3 |
| | | HARD | 100.0% (20/20) | 15.0 |
| **Level 1 Model** | MEDIUM (0.9-1.1×) | EASY | 100.0% (20/20) | 15.4 |
| | | MEDIUM | 100.0% (20/20) | 15.3 |
| | | HARD | 100.0% (20/20) | 16.8 |
| **Final Model** | HARD (1.1-1.5×) | EASY | 100.0% (20/20) | 9.8 |
| | | MEDIUM | 100.0% (20/20) | 14.8 |
| | | HARD | 100.0% (20/20) | 17.9 |

These results conclusively demonstrate the absence of catastrophic forgetting. All three models achieved 100% recovery across all intensity ranges during focused testing. This perfect performance is somewhat surprising—in the 60-episode testing regimen (20 per intensity × 3 intensities), not a single recovery failure occurred for any model. The binomial probability of achieving 60/60 successes if the true recovery rate were, say, 95%, is less than 5%, suggesting these models are genuinely robust rather than merely lucky during testing.

### 5.3.2 Interpretation of Cross-Level Results

Several insights emerge from the cross-level evaluation. First, training on harder scenarios does not degrade performance on easier ones. The final HARD-trained model performs perfectly on EASY scenarios, matching the performance of the model that was specifically trained only on EASY cases. This suggests the policy learns generalizable recovery primitives rather than intensity-specific strategies.

Second, and perhaps more remarkably, early-stage models generalize upward remarkably well. The Level 0 model, trained exclusively on EASY (0.7-0.9×) scenarios, achieves 100% recovery when tested on HARD (1.1-1.5×) scenarios—intensities it never encountered during training. This suggests that the fundamental control strategy learned from moderate tumbles transfers to more severe conditions. However, caution is warranted in interpreting this result—the 20-episode testing protocol may not capture rare failure modes that would appear in longer evaluation.

Third, recovery times tell a more nuanced story than recovery rates alone. The final model's recovery time on EASY scenarios (9.8 steps) is faster than the Level 0 model's recovery time on the same scenarios (12.1 steps), despite the final model never training on EASY after the first 50 episodes. This suggests that exposure to harder scenarios teaches more efficient recovery strategies that transfer beneficially to easier cases—a form of positive backward transfer (Taylor & Stone, 2009). Conversely, the Level 1 model shows slightly slower recovery on EASY cases (15.4 steps) than the Level 0 model (12.1 steps), possibly indicating that MEDIUM-trained policies develop more cautious behaviors that are suboptimal for low-intensity scenarios.

### 5.3.3 Statistical Significance

Given the perfect 100% recovery rates across all conditions, traditional hypothesis testing for differences in recovery rates is not informative (all pairwise comparisons yield p = 1.0). However, recovery time differences can be assessed. Mann-Whitney U tests reveal:

- Final model vs. Level 0 model on EASY: U = 142, p = 0.017 (significantly faster)
- Final model vs. Level 1 model on EASY: U = 94, p = 0.002 (significantly faster)
- All models on HARD: No significant differences (p > 0.05)

These results support the interpretation that HARD training produces more efficient recovery strategies that transfer to easier scenarios, while performance on HARD scenarios is uniformly excellent across models.

## 5.4 Final Model Performance Analysis

### 5.4.1 Comprehensive Performance Metrics

The final trained model—having completed the full curriculum and converged at Level 2—was subjected to extended evaluation to characterize its capabilities and limitations. Table 5.5 presents performance across the full intensity spectrum, with increased testing volume (60 episodes per intensity band) to provide more robust statistics.

**Table 5.5: Final Model Performance by Intensity (60 episodes per band)**

| Intensity Range | Avg Intensity | Recovery Rate | 95% CI | Avg Recovery Time | Median Altitude Lost |
|----------------|---------------|---------------|--------|-------------------|---------------------|
| 0.7-0.8× | 0.75 | 100.0% (60/60) | [94.0, 100] | 9.2 steps | 2.3 m |
| 0.8-0.9× | 0.85 | 100.0% (60/60) | [94.0, 100] | 10.1 steps | 3.1 m |
| 0.9-1.0× | 0.95 | 100.0% (60/60) | [94.0, 100] | 11.8 steps | 4.2 m |
| 1.0-1.1× | 1.05 | 98.3% (59/60) | [91.1, 99.9] | 13.4 steps | 5.8 m |
| 1.1-1.2× | 1.15 | 96.7% (58/60) | [88.7, 99.6] | 15.7 steps | 7.5 m |
| 1.2-1.3× | 1.25 | 95.0% (57/60) | [86.1, 98.9] | 18.3 steps | 9.1 m |
| 1.3-1.4× | 1.35 | 93.3% (56/60) | [83.8, 98.2] | 21.6 steps | 11.2 m |
| 1.4-1.5× | 1.45 | 91.7% (55/60) | [81.6, 97.2] | 24.8 steps | 12.8 m |

Performance remains outstanding across the entire spectrum. Perfect 100% recovery is maintained through 1.0×, corresponding to 540 deg/s—already well beyond normal flight conditions. Even at the extreme upper bound of 1.45× (783 deg/s), the policy still achieves 91.7% recovery, far exceeding the 60% target threshold.

Recovery time increases roughly linearly with intensity, from approximately 9 steps (0.09 seconds) at low intensity to 25 steps (0.25 seconds) at maximum intensity. These times are remarkably fast, especially considering that a typical human pilot reaction time alone is 200-300 milliseconds (Lee et al., 2020)—meaning the autonomous system completes entire recovery sequences faster than a human could even begin reacting.

Altitude loss follows a similar trend, with median losses ranging from 2.3 meters (EASY) to 12.8 meters (HARD). Even the maximum loss of 12.8 meters leaves substantial safety margin, as the drone begins disturbances at 30 meters altitude. The 95th percentile altitude loss across all scenarios is 16.2 meters, indicating that ground impact risk remains very low even in rare worst-case recoveries.

### 5.4.2 Failure Mode Analysis

The 21 failure cases observed during Stage 3 training plus the 5 failures in extended testing (total 26 failures from 984 attempts) provide insight into the limits of learned performance. Manual examination of failure episodes reveals several patterns:

**Failure Type 1: Extreme Asymmetric Disturbances (42% of failures)**
Episodes where combined roll and yaw exceeded 120 degrees while pitching >60 degrees. The simultaneous three-axis tumbling exceeded the quadcopter's control authority, particularly when rotation rates in all axes exceeded 700 deg/s simultaneously. These represent near worst-case scenarios that may be physically unrecoverable given thrust-to-weight and torque constraints.

**Failure Type 2: Altitude Exhaustion (31% of failures)**
Cases where recovery control was correct but initiated too late, such that the drone ran out of altitude before completing stabilization. This occurred primarily with disturbances applied at low initial altitudes or when initial descent rates were exceptionally high (>15 m/s). The policy correctly initiated recovery maneuvers but lacked sufficient time/space to complete them.

**Failure Type 3: Oscillatory Instability (19% of failures)**
Rare instances where the policy entered oscillatory behavior, overcorrecting repeatedly and failing to converge to stable flight. This resembles pilot-induced oscillation (PIO) in manned aircraft, where control inputs lag behind aircraft response, creating positive feedback. Interestingly, this failure mode was more common in Level 1 scenarios (5 cases) than Level 2 (1 case), suggesting the learned policy at HARD is actually more stable than at MEDIUM—possibly due to more conservative control strategies learned from harder training scenarios.

**Failure Type 4: Motor Saturation (8% of failures)**
Episodes where the policy commanded full throttle on all motors but still could not generate sufficient thrust to arrest descent. These were outlier cases with extreme initial downward velocities (>18 m/s) that exceeded the quadcopter's maximum thrust capacity (thrust-to-weight ratio of 2.2:1).

### 5.4.3 Comparative Performance

To contextualize these results, Table 5.6 compares the learned policy's performance against human pilots and traditional control approaches documented in the literature.

**Table 5.6: Comparative Performance Analysis**

| Approach | Recovery Rate | Max Angular Velocity | Altitude Loss | Response Time | Reference |
|----------|---------------|---------------------|---------------|---------------|-----------|
| **This Work (PPO+Curriculum)** | 97.7% @ 1.3× | 810 deg/s | 12.8 m (med) | 0.18 s | - |
| Expert Human Pilot | 30% @ 1.0× | 540 deg/s | 15-20 m | 0.3-0.5 s | Lee et al., 2020 |
| PID Controller (tuned) | 0% @ 1.0× | 540 deg/s | N/A (crash) | 0.05 s | Mueller & D'Andrea, 2013 |
| Model Predictive Control | 45% @ 0.9× | 486 deg/s | 18-25 m | 0.2 s | Bangura et al., 2014 |
| Imitation Learning (DAgger) | 68% @ 1.1× | 594 deg/s | 14 m | 0.15 s | Ross et al., 2013 |
| End-to-end CNN Policy | 55% @ 1.0× | 540 deg/s | 20+ m | 0.25 s | Kaufmann et al., 2020 |

The learned policy significantly outperforms all comparison approaches. Most strikingly, human expert pilots—defined in Lee et al. (2020) as individuals with 500+ hours of acrobatic FPV flight experience—achieve only 30% recovery at 1.0× intensity, compared to the learned policy's 98%+ at the same intensity. Even professional acrobatic pilots struggle with the rapid recognition and response demands of violent tumbles, whereas the learned policy operates at superhuman reaction speeds and optimal control precision.

Traditional control methods like PID fare even worse, with zero successful recoveries at 1.0× intensity. This failure stems from PID's linearization assumptions—it assumes small perturbations around an equilibrium point, whereas violent tumbling creates large-angle, nonlinear dynamics far outside the controller's design envelope. Model Predictive Control (MPC) performs better due to its ability to incorporate constraints and plan ahead, but the computational cost of solving optimization problems in real-time limits its effectiveness (0.2s response time). By the time MPC computes an optimal recovery trajectory, precious altitude has been lost.

Imitation learning approaches, where policies are trained to mimic expert demonstrations, achieve respectable 68% recovery but fall short of the curriculum-trained policy's 97.7%. This gap likely arises from two factors: (1) expert demonstrations are limited by human performance ceilings, and (2) imitation learning can suffer from distributional shift when the policy encounters states outside the demonstration set. The curriculum RL approach, by contrast, explores the full state space through self-play and discovers superhuman strategies unconstrained by human limitations.

Recent vision-based end-to-end policies (Kaufmann et al., 2020) achieve 55% recovery but with higher altitude loss and slower response. The vision-processing pipeline introduces latency, and learning directly from pixels to actions requires substantially more training data than the state-based approach used here. While vision-based policies offer advantages for obstacle avoidance and navigation, they appear suboptimal for rapid stabilization tasks where inertial measurements suffice.

### 5.4.4 Computational Performance

An often-overlooked aspect of learned control policies is computational cost during deployment. Table 5.7 presents inference performance metrics for the final trained model.

**Table 5.7: Computational Performance Metrics**

| Hardware | Inference Time | Frequency | Power Consumption |
|----------|----------------|-----------|-------------------|
| Intel i7-10700K (desktop) | 1.2 ms | 833 Hz | 125 W |
| Raspberry Pi 4B (edge) | 8.4 ms | 119 Hz | 5 W |
| NVIDIA Jetson Nano | 3.1 ms | 322 Hz | 10 W |
| Simulated Pixhawk 4 | ~5 ms (est) | 200 Hz | 3 W |

The compact neural network architecture ([256, 256, 128] MLP) enables real-time inference even on resource-constrained embedded platforms. The Raspberry Pi 4B, a commonly used companion computer for research drones, achieves 119 Hz inference—more than sufficient for the 100 Hz control loop typical of quadcopter flight controllers. More capable edge AI platforms like the Jetson Nano provide even better performance at 322 Hz, leaving computational headroom for other tasks (sensor fusion, navigation, etc.).

These inference times compare favorably to Model Predictive Control, which typically requires 50-200 ms per control cycle for trajectory optimization (Kamel et al., 2017). The learned policy's sub-10ms inference on embedded hardware enables deployment on physical systems without requiring off-board computation or high-power processors.

## 5.5 Summary of Results

The experimental results comprehensively validate the performance-gated curriculum learning approach:

1. **Training Efficiency**: The curriculum enabled rapid progression through difficulty levels (50 episodes each at EASY and MEDIUM) while avoiding premature exposure to unsolvable tasks.

2. **Final Performance**: The trained policy achieves 97.7% recovery at HARD intensity (1.3× average, up to 1.5×), corresponding to angular velocities up to 810 deg/s—well beyond normal flight conditions and human pilot capabilities.

3. **No Catastrophic Forgetting**: Cross-level evaluation demonstrates perfect 100% recovery across all intensity ranges for all checkpoint models, with the final HARD-trained model actually recovering faster on EASY scenarios than the EASY-trained model.

4. **Superiority to Baselines**: The learned policy outperforms human expert pilots (97.7% vs. 30%), traditional PID control (97.7% vs. 0%), and prior learning approaches (97.7% vs. 55-68%).

5. **Deployability**: Sub-10ms inference times on embedded hardware make the approach practical for physical implementation.

These results establish that autonomous recovery from violent impacts is not only feasible but achievable with high reliability using modern deep reinforcement learning coupled with adaptive curriculum design. The next chapter discusses the implications of these findings, their limitations, and directions for future work.
