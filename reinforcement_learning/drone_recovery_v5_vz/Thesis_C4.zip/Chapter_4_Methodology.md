# CHAPTER 4: METHODOLOGY

## 4.1 Introduction

This chapter presents the systematic approach developed for enabling autonomous mid-air recovery in quadcopter UAVs following severe impact disturbances. The methodology integrates reinforcement learning with performance-gated curriculum design to address the fundamental challenge of learning robust recovery behaviors from violent tumbling states. Rather than employing traditional control approaches that rely on precise mathematical models—which often fail under extreme conditions—this work leverages deep reinforcement learning to discover control policies directly from interaction with a high-fidelity simulation environment.

The development process comprises three distinct stages, each building upon the previous to incrementally increase system capability. Stage 1 establishes baseline hovering stability, Stage 2 introduces basic disturbance recovery, and Stage 3 implements the novel performance-gated curriculum that forms the core contribution of this research. This staged approach mirrors best practices in reinforcement learning for robotics (Andrychowicz et al., 2020) while introducing adaptive progression mechanisms that address the specific challenges of violent impact recovery.

## 4.2 Experimental Platform and Simulation Environment

### 4.2.1 AirSim Simulation Platform

The research utilizes Microsoft AirSim (Shah et al., 2018), an open-source simulator built on Unreal Engine 4, providing photorealistic rendering and physically accurate flight dynamics. AirSim was selected over alternatives such as Gazebo or RotorS for several compelling reasons. First, its integration with Unreal Engine delivers real-time physics simulation at sufficient fidelity to capture the complex aerodynamics of tumbling flight without requiring simplifying assumptions. Second, the platform provides direct Python API access, enabling seamless integration with modern deep learning frameworks. Third, AirSim's multirotor physics model incorporates realistic motor dynamics, propeller aerodynamics, and environmental effects—critical for simulating the transient behaviors that occur during violent disturbances.

The simulation runs at 100 Hz control frequency with physics timesteps of 0.01 seconds, matching the typical update rates of commercial flight controllers. This temporal resolution ensures that rapid attitude changes during tumbling are accurately captured. Environmental parameters were configured to represent standard atmospheric conditions: temperature of 25°C, pressure of 101.325 kPa, and negligible wind (though wind capability was retained for future work). The simulated quadcopter employs a standard X-configuration with 0.45-meter arm length and 2.5 kg total mass, representative of mid-sized research UAVs.

### 4.2.2 State Space Representation

The observation space provides the agent with comprehensive situational awareness through 15 continuous state variables (Table 4.1). This design balances information richness with learning tractability—a critical consideration in high-dimensional reinforcement learning (Mnih et al., 2015). Position and velocity information enables altitude maintenance and descent rate management. Attitude (roll, pitch, yaw) and angular rates capture the drone's orientation and rotational dynamics, which are paramount during tumbling recovery. Previous motor commands serve as proprioceptive feedback, helping the policy account for actuator saturation and response delays.

**Table 4.1: State Space Components**

| Category | Variables | Range | Justification |
|----------|-----------|-------|---------------|
| Position | x, y, z | ±100 m | Spatial awareness for altitude recovery |
| Velocity | vx, vy, vz | ±20 m/s | Descent rate monitoring |
| Attitude | roll, pitch, yaw | ±π rad | Orientation for stability assessment |
| Angular Rates | ωx, ωy, ωz | ±20 rad/s | Tumbling dynamics detection |
| Previous Action | motor 0-3 | [0, 1] | Actuator state memory |

The state variables are normalized to standard ranges to improve neural network training stability (Ioffe & Szegedy, 2015). Importantly, the state representation excludes camera imagery, instead relying entirely on inertial and kinematic measurements. This decision was deliberate: successful recovery from violent tumbling depends primarily on immediate stabilization rather than visual scene understanding. By constraining the observation space to flight-critical measurements available from typical IMU sensors, the learned policies remain transferable to physical hardware without requiring onboard vision processing.

### 4.2.3 Action Space Design

The agent outputs continuous actions in the form of normalized motor commands for each of the four rotors. This low-level control approach was chosen over higher-level abstractions (such as desired attitude setpoints) to provide the policy with maximum control authority during extreme conditions. When a drone is tumbling at 600+ degrees per second, conventional cascaded control loops may lack the response time to prevent ground impact. Direct motor control allows the learning algorithm to discover unconventional recovery maneuvers that violate typical flight control assumptions—for instance, briefly increasing motor thrust asymmetrically to induce corrective torques even while inverted.

Actions are bounded to [0, 1] and processed through a nonlinear mapping to motor PWM signals, incorporating realistic constraints such as minimum and maximum throttle limits. A smoothing filter with time constant τ = 0.05s attenuates abrupt command changes, preventing actuator saturation while maintaining responsiveness. This design mirrors the motor mixing logic found in popular open-source flight controllers like PX4 and ArduPilot (Meier et al., 2015).

## 4.3 Reinforcement Learning Framework

### 4.3.1 Proximal Policy Optimization

Proximal Policy Optimization (PPO) (Schulman et al., 2017) was selected as the core learning algorithm after preliminary experiments with alternative approaches. PPO offers several advantages for continuous control tasks in robotics: it is sample-efficient compared to older policy gradient methods, exhibits stable training behavior through clipped objective functions, and achieves state-of-the-art performance across diverse control benchmarks (Huang et al., 2022). The algorithm's stability is particularly important for safety-critical applications where training instabilities could result in dangerous learned behaviors.

The PPO implementation utilizes the following hyperparameters, carefully tuned through systematic experimentation:

**Table 4.2: PPO Hyperparameters**

| Parameter | Value | Justification |
|-----------|-------|---------------|
| Learning Rate | 3×10⁻⁴ | Standard for continuous control (Engstrom et al., 2020) |
| Discount Factor (γ) | 0.99 | Prioritizes long-term stability over immediate reward |
| GAE Lambda (λ) | 0.95 | Reduces variance while maintaining bias-variance tradeoff |
| Clip Range (ε) | 0.2 | Prevents excessive policy updates (Schulman et al., 2017) |
| Entropy Coefficient | 0.01 | Encourages exploration without sacrificing convergence |
| Value Function Coeff | 0.5 | Balances policy and value function learning |
| Batch Size | 64 | Computational efficiency on consumer hardware |
| Training Epochs | 10 | Multiple passes over collected experience |
| Rollout Length | 2048 steps | Sufficient trajectory length for temporal credit assignment |

The policy network employs a multi-layer perceptron architecture with [256, 256, 128] hidden units and hyperbolic tangent (tanh) activation functions. This relatively compact architecture was deliberately chosen to maintain computational efficiency—enabling real-time inference on resource-constrained flight computers—while providing sufficient representational capacity for the control task. The value function shares the same architecture but operates independently, allowing distinct learning rates for policy and critic updates.

### 4.3.2 Reward Function Design

Reward shaping represents one of the most critical and challenging aspects of reinforcement learning for robotics (Ng et al., 1999). The reward function must encode the desired behavior—successful recovery and stable flight—while being dense enough to provide useful learning signals. After extensive experimentation, the final reward structure combines multiple components:

**Altitude Maintenance Reward:**
```
r_altitude = -|z_target - z_current|²
```

This quadratic penalty encourages the drone to maintain the target altitude of 30 meters. The squared term creates stronger penalties for large deviations, motivating aggressive corrective action when falling rapidly.

**Orientation Stability Reward:**
```
r_orientation = -α(|φ| + |θ| + |ψ|)
```

where φ, θ, ψ represent roll, pitch, and yaw angles, and α = 2.0 scales the contribution. This term penalizes deviations from level flight, with the L1 norm chosen over L2 to create steeper gradients near the upright orientation.

**Angular Velocity Penalty:**
```
r_angular = -β(ωx² + ωy² + ωz²)
```

with β = 0.5, discouraging excessive rotation rates. This component is crucial for damping oscillations during recovery attempts.

**Recovery Bonus:**
```
r_recovery = {
    +5000  if tumble detected AND successfully recovered
    0      otherwise
}
```

A large sparse reward is granted upon successful recovery, providing a clear learning signal for the primary objective. The magnitude (5000) was calibrated to be significant relative to per-step rewards, ensuring the policy prioritizes recovery over other objectives.

**Crash Penalty:**
```
r_crash = {
    -1000  if altitude < 2m OR excessive tilt
    0      otherwise
}
```

Terminal penalties discourage unsafe behaviors, though the magnitude is intentionally smaller than the recovery bonus to avoid excessively conservative policies.

The total reward at each timestep combines these components:
```
r_total = r_altitude + r_orientation + r_angular + r_recovery + r_crash - 1
```

The constant penalty of -1 per timestep creates implicit time pressure, encouraging efficient recovery. This reward structure emerged through iterative refinement—initial designs either provided insufficient learning signal during tumbling (too sparse) or created local optima where the agent avoided disturbances entirely (poor exploration).

## 4.4 Performance-Gated Curriculum Learning

### 4.4.1 Motivation and Design Philosophy

The core innovation of this work lies in the performance-gated curriculum learning approach. Traditional curriculum learning for robotics typically follows predetermined progression schedules (Narvekar et al., 2020), advancing to harder tasks after a fixed number of episodes or based on elapsed time. However, such rigid schedules fail to account for the inherent variability in learning progress—some concepts are mastered quickly while others require extended practice. Premature advancement exposes the learning agent to scenarios beyond its current capability, often leading to training collapse. Conversely, excessive time on mastered skills wastes computational resources and risks overfitting to easy scenarios.

The performance-gated approach addresses these limitations through adaptive progression based on empirical success rates. The system monitors rolling-window performance and advances to the next difficulty level only when the agent demonstrates consistent mastery at the current level. This design philosophy draws inspiration from human skill acquisition: just as a student pilot must demonstrate proficiency in basic maneuvers before attempting aerobatics, the reinforcement learning agent must prove competence at moderate disturbances before facing extreme tumbles.

### 4.4.2 Curriculum Level Definitions

Three difficulty levels were defined based on disturbance intensity multipliers applied to baseline tumbling scenarios (Table 4.3). The intensity multiplier scales the magnitude of induced angular velocities, directly controlling the severity of the recovery challenge.

**Table 4.3: Curriculum Level Specifications**

| Level | Name | Intensity Range | Angular Velocity | Target Recovery Rate |
|-------|------|-----------------|------------------|---------------------|
| 0 | EASY | 0.7-0.9× | 378-486 deg/s | 80% |
| 1 | MEDIUM | 0.9-1.1× | 486-594 deg/s | 70% |
| 2 | HARD | 1.1-1.5× | 594-810 deg/s | 60% |

Level 0 (EASY) represents disturbances at the lower bound of tumbling severity—still far beyond normal flight conditions, but within the recovery envelope of a well-tuned policy. Level 1 (MEDIUM) approaches the limits of what analytical control methods can handle, requiring rapid but feasible corrective maneuvers. Level 2 (HARD) pushes into territory where successful recovery demands near-optimal control sequences and precise timing. The upper bound of 810 deg/s represents extreme conditions unlikely in real-world scenarios but valuable for building robust policies with safety margins.

The intensity ranges were determined through preliminary testing to ensure each level presents meaningful challenge progression without creating insurmountable difficulty gaps. Adjacent levels overlap slightly (e.g., 0.9× appears in both EASY and MEDIUM ranges) to provide continuity during transitions.

### 4.4.3 Advancement Criteria and Gating Mechanism

The advancement logic employs a rolling window approach to assess performance stability over recent experience. Specifically, the system maintains a buffer of the last 50 episode outcomes (recovered or crashed). When this buffer reaches capacity, the recovery rate is calculated as:

```
R = (Σ success_i) / N,  where N = 50
```

Advancement to level L+1 occurs if and only if:
```
R ≥ θ_L
```

where θ_L is the threshold for level L (Table 4.3: 80%, 70%, 60% for levels 0, 1, 2 respectively).

Upon advancement, three critical actions occur:
1. The curriculum level increments (L ← L+1)
2. The rolling window buffer resets (ensuring fresh evaluation at the new level)
3. The current policy is saved as a checkpoint for later analysis

The window size of 50 episodes represents a deliberate balance between statistical significance and responsiveness to learning progress. Smaller windows (e.g., 10-20 episodes) would be too sensitive to random fluctuations, potentially causing premature advancement after a lucky streak. Larger windows (e.g., 100+ episodes) would delay advancement unnecessarily and reduce training efficiency. The value of 50 episodes provides sufficient samples for meaningful statistics (standard error ≈ 7%) while maintaining adaptive behavior.

The descending threshold schedule (80% → 70% → 60%) acknowledges that harder tasks inherently have lower achievable success rates, even for optimal policies. Requiring 80% recovery at the HARD level would be unrealistic and likely unattainable, as some disturbance configurations may be physically unrecoverable given the drone's thrust-to-weight ratio and response dynamics. The chosen thresholds reflect this pragmatism while still ensuring meaningful competence before progression.

### 4.4.4 Training Procedure

Training follows a three-stage protocol, with each stage building upon the previous:

**Stage 1: Baseline Stabilization**
- Objective: Establish stable hovering at 30m altitude
- Duration: 100,000 timesteps (~2 hours)
- Environment: No disturbances; reward focused on altitude and orientation
- Success Criterion: 95% episodes terminate with stable hover

**Stage 2: Basic Recovery**
- Objective: Introduce recovery capability for mild disturbances
- Duration: 200,000 timesteps (~4 hours)
- Environment: Fixed intensity disturbances at 1.0× (540 deg/s)
- Success Criterion: 70% recovery rate over final 100 episodes

**Stage 3: Performance-Gated Curriculum**
- Objective: Master the full spectrum of disturbance intensities
- Duration: Adaptive (until 600,000 timesteps or convergence)
- Environment: Dynamic curriculum as described in Section 4.4.3
- Success Criterion: Stable performance at Level 2 (HARD)

This staged approach ensures the policy has fundamental flight skills before facing the complexity of violent tumbling. Direct application of the curriculum to an untrained agent would likely fail, as the policy would lack even basic stability to build upon.

## 4.5 Evaluation Methodology

### 4.5.1 Training Performance Metrics

During training, multiple metrics were logged at episode resolution to track learning progress:

1. **Episode Reward**: Total cumulative reward, providing a general indicator of policy improvement
2. **Recovery Rate (Rolling)**: Success percentage over sliding windows of 10 and 50 episodes
3. **Recovery Time**: Number of timesteps from disturbance detection to stable flight
4. **Curriculum Level**: Current difficulty level (0-2)
5. **Disturbance Intensity**: Actual multiplier applied in each episode

These metrics enable comprehensive analysis of learning dynamics and curriculum progression behavior.

### 4.5.2 Cross-Level Evaluation Protocol

To rigorously assess catastrophic forgetting and generalization, each saved checkpoint model (Level 0 mastered, Level 1 mastered, and final model) was systematically tested across all three intensity ranges. This cross-evaluation involved:

- 20 episodes per model per intensity level
- Deterministic policy evaluation (no exploration noise)
- Identical initial conditions and random seeds across models
- Recording of recovery rate, average recovery time, and final altitude

This protocol enables direct comparison of how each policy performs on intensities it was trained on versus those below and above its training distribution.

### 4.5.3 Statistical Analysis

Recovery rates are reported with binomial confidence intervals using the Wilson score method (Brown et al., 2001), which provides accurate coverage even for extreme success rates near 0% or 100%. Differences between models are assessed using two-proportion z-tests, with statistical significance defined as p < 0.05. Recovery time distributions are compared using Mann-Whitney U tests due to their non-normal nature (often exhibiting positive skew from occasional prolonged recovery attempts).

## 4.6 Implementation Details

All training was conducted on a desktop workstation with the following specifications:
- CPU: AMD Ryzen 9 5900X (12 cores)
- RAM: 64 GB DDR4-3600
- GPU: NVIDIA RTX 3080 (10 GB VRAM)
- OS: Ubuntu 20.04 LTS

The complete software stack comprised:
- Python 3.8
- PyTorch 1.12.0 (deep learning framework)
- Stable-Baselines3 1.6.0 (PPO implementation)
- AirSim 1.8.1 (simulation environment)
- NumPy 1.23.0, Gymnasium 0.26.0 (supporting libraries)

Training utilized CPU-based inference with GPU-accelerated gradient computation. The AirSim simulator ran in headless mode (no rendering) to maximize simulation throughput, achieving approximately 5× real-time speed. Total wall-clock training time for Stage 3 was 14.7 hours, corresponding to 600,000+ timesteps of simulated experience.

All code, hyperparameter configurations, and training logs are available in the supplementary materials to support reproducibility.

## 4.7 Summary

This chapter has detailed the comprehensive methodology developed for autonomous impact recovery in quadcopter UAVs. The approach combines high-fidelity simulation, modern deep reinforcement learning, and a novel performance-gated curriculum mechanism. The curriculum design addresses a fundamental challenge in learning robust recovery behaviors: balancing training efficiency with capability breadth. By adaptively progressing through difficulty levels based on demonstrated competence, the system avoids both premature exposure to unsolvable tasks and excessive dwelling on mastered skills.

The next chapter presents experimental results, demonstrating that this methodology successfully produces policies capable of recovering from disturbances up to 810 deg/s with 97.7% success rate—performance that significantly exceeds both human pilot capabilities and traditional control approaches.
